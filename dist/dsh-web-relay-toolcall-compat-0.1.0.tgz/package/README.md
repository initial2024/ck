# dsh-web-relay-toolcall-compat

DSH compatibility bundle for non-API DeepSeek web-relay outputs that express tool calls as Chinese text instead of native DSH `tool-call` chunks.
